
extern void init_LED16x16(void);

extern void display_LED16x16(uint8_t data[32]);
