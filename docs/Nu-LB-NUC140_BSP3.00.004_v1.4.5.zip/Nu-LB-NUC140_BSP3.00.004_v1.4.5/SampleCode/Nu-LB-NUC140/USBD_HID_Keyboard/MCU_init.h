//Define Clock source
#define MCU_CLOCK_SOURCE      
#define MCU_CLOCK_SOURCE_HXT    // HXT, LXT, HIRC, LIRC 
#define MCU_CLOCK_FREQUENCY     48000000  //Hz

//Define MCU Interfaces
#define MCU_INTERFACE_USB
#define USB_CLOCK_DIVIDER     1
