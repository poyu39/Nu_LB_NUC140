
usbser.sys is required for USB Virtual COM device.
It is included by windows operation system and could be found at \WINDOWS\system32\drivers
or \i386\driver.cab

To install the VCOM driver, user must find usbser.sys on their OS first and copy it to the same directory with Nuvoton CDC INF file. Finally install the driver manually when windows request to install the VCOM device driver.